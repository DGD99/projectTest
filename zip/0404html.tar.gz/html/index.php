<!DOCTYPE html>
<html>
<head>
	<title> 테스트페이지 </title>
	<meta charset="UTF-8">
</head>
<body>
<center><h2> 테스트 페이지 </h2>
	<a href="check.php"> 클릭하세요 </a><br>
	<a href="/backend/auth-sign-up.html">회원가입 페이지</a>

</center>
<?php
	echo "위의 링크를 클릭하세요";
?>
</body>
</html>
