<?php
	echo "파일 업로드 테스트";

	$con=mysqli_connect("10.5.103.50","root","TEst!234","webdb") or die("접속실패");

	session_start();

	$username=$_SESSION["username"];
	$useremail=$_SESSION["useremail"];

	echo $username;

	$sql="SELECT filesize FROM filetbl WHERE username = '{$username}' ";
	
	$ret = mysqli_query($con,$sql);

	if (isset($_FILES)) {
    		$file = $_FILES["file"];
    		$error = $file["error"];
    		$name = $file["name"];
    		$type = $file["type"];
    		$size = $file["size"];
    		$tmp_name = $file["tmp_name"];
   
    		if ( $error > 0 ) {
        	echo "Error: " . $error . "<br>";
    		}
    		else {
        		$temp = explode(".", $name);
        		$extension = end($temp);
       
            		echo "Upload: " . $name . "<br>";
            		echo "Type: " . $type . "<br>";
            		$size;
            		echo "Stored in: " . $tmp_name;
            		if (file_exists( "/upload/" . $username . "/" . $name)) {
                		echo $name . " already exists. ";
            		}	
            		else {
				
				$orisize_total=0;
				while($rows=mysqli_fetch_assoc($ret))
                                        { 
						$orisize_total += $rows['filesize'];				
					}
				echo "<br><br><br><br> originalsize:";
				echo $orisize_total;
				echo "<br><br>";
				$filesize_sum = $size + $orisize_total;
				
				echo "filesum:";
				echo $filesize_sum;

				if ($filesize_sum >= 10000000) {
					echo "데이터 입력 실패 사이즈 초과 <br>";

?>
	<script>
		alert('업로드 실패: 디스크 공간이 부족합니다.');
		location.href = "page-alexa.php";
	</script>
<?php	
				
				}
				else {
                		
					move_uploaded_file($tmp_name, "/upload/" . $username . "/" . $name);
                			echo "Stored in: " . "/upload/" . $name;
					$sql="INSERT INTO filetbl VALUES(NULL, '".$name."', '" .$useremail ."', NULL ,'".$size."' , '".$username."' )";
		
					$ret = mysqli_query($con,$sql);
				
            
					if($ret) {
                				echo "데이터 입력 완료";
					}
				
				else {
                			echo "데이터 입력 실패"."<br>";
                			echo "실패원인 : ".mysqli_error($con);
	    			}
	   		}
?>
	<script>
		alert('업로드 성공');
                location.href = "page-alexa.php";
	</script>
<?php
    	  }
	}
	}
	else {
    		echo "File is not selected";

?>
	<script>
		alet('업로드 실패');
                location.href = "page-alexa.php";
	</script>
<?php
	
	}	
	
	mysqli_close($con);

?>
