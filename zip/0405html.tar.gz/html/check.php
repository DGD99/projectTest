<?php
	$db_host="10.5.103.50";
	$db_user="root";
	$db_password="TEst!234";
	$db_name="webdb";
	$con=mysqli_connect($db_host, $db_user, $db_password, $db_name);

	if( mysqli_connect_error($con) ) {
		echo "접속 실패","<br>";
		echo "오류 원인:", mysqli_connect_error();
		exit();
	}
	echo "MYSQL 연결 성공";


	$sql="SELECT filename, filesize FROM filetbl";

	$ret = mysqli_query($con,$sql);

	while ($row = mysqli_fetch_assoc($ret)){

      echo 'filename : '.$row['filename'].', filesize : '.$row['filesize'].'<br>';

   	}


	mysqli_close($con);
?>
