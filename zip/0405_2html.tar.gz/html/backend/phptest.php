<?php
	phpinfo();


?>
