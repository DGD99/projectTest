<?php

	session_start();

	$username= $_SESSION["username"];

	$filename = $_REQUEST['filename'];

	$con=mysqli_connect("10.5.103.50","root","TEst!234","webdb") or die("접속실패");

	$fileDir = "/upload";	

	$fullPath = $fileDir."/" . $username . "/" .$filename;

	header("Content-Type: application/octet-stream");

	header("Content-Disposition: attachment; filename=".iconv('utf-8','euc-kr',$filename));

	header("Content-Transfer-Encoding: binary");

	$fh = fopen($fullPath, "r");

	fpassthru($fh);

	

?>
